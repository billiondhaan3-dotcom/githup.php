<?php

echo "<h1 style='color:blue;'>jamhuriya university of science & technology</h1>";

echo "<h4 style='color:green;font-size:24px;'>about information</h4>";

echo "
Jamhuriya University of Science and Technology (JUST) is private institution
and was officially established in Mogadishu, Somalia, in 2011 by a group of
Somali scholars and intellectuals to fill the existing vacuum in the higher
education system in Somalia by providing higher education of international standards.
";

echo "<h2 style='color:green; font-size:24px;'>contact information</h2>";
echo "
Email: info@just.edu.so <br>
Phone: +252 612 223999 <br>
Address: Digfeer Street, Hodon District <br>
Website: <a href='https://just.edu.so'>Visit Website</a>
";

?>